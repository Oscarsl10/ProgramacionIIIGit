import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { PumaService } from './puma.service';
import { Pumac } from './pumac';

@Component({
  selector: 'app-puma',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './puma.component.html',
  styleUrl: './puma.component.css'
})
export class PumaComponent implements OnInit{

  puma: Pumac[];

  constructor (private pumaService : PumaService){
    
  }
  ngOnInit(): void {
    this.pumaService.getPuma().subscribe(
      puma=> this.puma = puma
    )
  }

}
