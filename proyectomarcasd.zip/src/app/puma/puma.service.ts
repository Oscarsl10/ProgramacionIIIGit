import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { Pumac } from './pumac';
import { PUMA } from './puma.json';

@Injectable({
  providedIn: 'root'
})
export class PumaService {

  constructor() { }

  getPuma(): Observable <Pumac[]> {return of (PUMA);}
}
