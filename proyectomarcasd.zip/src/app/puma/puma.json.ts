import { Pumac } from "./pumac"

export const PUMA: Pumac[]=[
    {id: 1, nombre:"Puma", fundacion: 1948, origen: "Alemania", ingresos_anuales: 5700, empleados: 14000}
]