export class Adidasc {
    id: number;
    nombre: string;
    fundacion: number;
    origen: string;
    ingresos_anuales: number;
    empleados: number;
}
