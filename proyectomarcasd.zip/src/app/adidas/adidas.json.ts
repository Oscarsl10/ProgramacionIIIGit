import { Adidasc } from "./adidasc"

export const ADIDAS: Adidasc[]=[
    {id: 1, nombre:"Adidas", fundacion: 1949, origen: "Alemania", ingresos_anuales: 23900, empleados: 62000}
]