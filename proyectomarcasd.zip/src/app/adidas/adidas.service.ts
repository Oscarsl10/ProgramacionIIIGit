import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { Adidasc } from './adidasc';
import { ADIDAS } from './adidas.json';

@Injectable({
  providedIn: 'root'
})
export class AdidasService {

  constructor() { }

  getAdidas(): Observable <Adidasc[]> {return of (ADIDAS);}
}
