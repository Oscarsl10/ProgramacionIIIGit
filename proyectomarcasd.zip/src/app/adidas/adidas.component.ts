import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Adidasc } from './adidasc';
import { AdidasService } from './adidas.service';

@Component({
  selector: 'app-adidas',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './adidas.component.html',
  styleUrl: './adidas.component.css'
})
export class AdidasComponent implements OnInit{
  
  adidas: Adidasc[];

  constructor(private adidasService: AdidasService){

  }

  ngOnInit(): void {
    this.adidasService.getAdidas().subscribe(
      adidas=> this.adidas = adidas 
    )
  }

}
