import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { Nikec } from './nikec';
import { NIKE } from './nike.json';

@Injectable({
  providedIn: 'root'
})
export class NikeService {

  constructor() { }

  getNike(): Observable <Nikec[]> {return of (NIKE);}
}
