import { Nikec } from "./nikec"

export const NIKE: Nikec[]=[
    {id: 1, nombre:"Nike", fundacion: 1964, origen: "Estados Unidos", ingresos_anuales: 38700, empleados: 75900}
]