package com.corhuila.marcas_deportivas.models.dao;

import com.corhuila.marcas_deportivas.models.entity.marcas_deportivas;
import org.springframework.data.repository.CrudRepository;

public interface Imarcas_deportivasDao extends CrudRepository <marcas_deportivas, Long> {
}
