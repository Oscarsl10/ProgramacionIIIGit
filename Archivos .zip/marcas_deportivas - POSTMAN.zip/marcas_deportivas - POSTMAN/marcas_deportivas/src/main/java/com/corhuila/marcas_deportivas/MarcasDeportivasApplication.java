package com.corhuila.marcas_deportivas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MarcasDeportivasApplication {

	public static void main(String[] args) {
		SpringApplication.run(MarcasDeportivasApplication.class, args);
	}

}
