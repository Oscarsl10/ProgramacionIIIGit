package com.corhuila.marcas_deportivas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MarcasDeportivasApplicationTests {

	@Test
	void contextLoads() {
	}

}
