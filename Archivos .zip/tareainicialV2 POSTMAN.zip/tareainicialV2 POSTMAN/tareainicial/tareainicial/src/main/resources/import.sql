INSERT INTO tareas (nom_tarea, descripcion, email, responsable) VALUES ("Calculo", "LALALLA", "Oscar", "ogsierra@corguila")
INSERT INTO tareas (nom_tarea, descripcion, email, responsable) VALUES ("Calculo", "LALALLA", "Oscar", "ogsierra@corguila")
INSERT INTO tareas (nom_tarea, descripcion, email, responsable) VALUES ("Calculo", "LALALLA", "Oscar", "ogsierra@corguila")
INSERT INTO tareas (nom_tarea, descripcion, email, responsable) VALUES ("Calculo", "LALALLA", "Oscar", "ogsierra@corguila")