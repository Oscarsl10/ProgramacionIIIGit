export class Marcadeportiva {
    id: number;
    nombre: string;
    fundacicion: number;
    origen: string;
    ingresos_anuales: number;
    empleados: number;
}
