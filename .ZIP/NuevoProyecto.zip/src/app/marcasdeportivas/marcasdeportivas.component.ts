import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Marcadeportiva } from './marcadeportiva';



@Component({
  selector: 'app-marcasdeportivas',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './marcasdeportivas.component.html',
  styleUrl: './marcasdeportivas.component.css'
})
export class marcasdeportivasComponent implements OnInit{
  marcasdeportivas: Marcadeportiva[] = [
    {id: 1, nombre: 'Nike', fundacicion: 1964, origen: 'Estados Unidos', ingresos_anuales: 38700, empleados: 75900}
  ]

  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }
  
  
}
