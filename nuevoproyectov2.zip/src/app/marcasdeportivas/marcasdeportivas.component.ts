import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Marcadeportiva } from './marcadeportiva';



@Component({
  selector: 'app-marcasdeportivas',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './marcasdeportivas.component.html',
  styleUrl: './marcasdeportivas.component.css'
})
export class marcasdeportivasComponent implements OnInit{
  marcasdeportivas: Marcadeportiva[] = [
    {id: 1, nombre: 'Nike', fundacicion: 1964, origen: 'Estados Unidos', ingresos_anuales: 38700, empleados: 75900},
    {id: 2, nombre: 'Adidas', fundacicion: 1949, origen: '', ingresos_anuales: 23900, empleados: 62000},
    {id: 3, nombre: 'Puma', fundacicion: 1948, origen: 'Alemania', ingresos_anuales: 5700, empleados: 14000}
  ]

  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }
  
  
}
